
function switchLang(lang) {
  const data = {
    vi: {
      "title": "DonTech - CompSuperTech IT Solutions",
      "email": "Email: compsupertech@gmail.com",
      "services-title": "Dịch Vụ Sửa Chữa & Hỗ Trợ Kỹ Thuật",
      "contact-title": "Liên hệ hỗ trợ",
      "label-name": "Họ tên:",
      "label-email": "Email hoặc SĐT:",
      "label-service": "Dịch vụ cần hỗ trợ:",
      "submit-button": "Gửi yêu cầu",
      "qr-title": "Quét mã QR để liên hệ nhanh"
    },
    en: {
      "title": "DonTech - CompSuperTech IT Solutions",
      "email": "Email: compsupertech@gmail.com",
      "services-title": "IT Support & Repair Services",
      "contact-title": "Contact Support",
      "label-name": "Full Name:",
      "label-email": "Email or Phone:",
      "label-service": "Service Request:",
      "submit-button": "Send Request",
      "qr-title": "Scan QR code to contact quickly"
    }
  };

  const selected = data[lang];
  for (const id in selected) {
    document.getElementById(id).textContent = selected[id];
  }
}
